package com.ckcelliot.estore.Entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "orders")
@Data
public class Order {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String orderTrackingNumber;
	private int totalQuantity;
	private BigDecimal totalPrice;
	private String status;

	@CreationTimestamp
	private LocalDateTime dateCreated;

	@UpdateTimestamp
	private LocalDateTime lastUpdated;

	// default fetch type for one to many is LAZY
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "order", orphanRemoval = true)
	private Set<OrderItem> orderItems = new HashSet<>();

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id")
	private User user;

	public BigDecimal getTotalAmount() {
		BigDecimal amount = new BigDecimal(0.0);
		for (OrderItem item : this.orderItems) {
			amount = amount.add(item.getPrice());
		}
		return amount;
	}

	@Override
	public String toString() {
		return "Order [id=" + id +
				", orderTrackingNumber=" + orderTrackingNumber +
				", totalQuantity=" + totalQuantity +
				", totalPrice=" + totalPrice + ", status=" + status + ", dateCreated=" + dateCreated +
				", lastUpdated=" + lastUpdated + "orderItems=" + orderItems + "]";
	}

}

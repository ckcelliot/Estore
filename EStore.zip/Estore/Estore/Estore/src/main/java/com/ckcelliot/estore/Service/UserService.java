package com.ckcelliot.estore.Service;

import com.ckcelliot.estore.Entity.User;
import org.springframework.stereotype.Service;

@Service
public interface UserService {

    public User getUserDetails();

}

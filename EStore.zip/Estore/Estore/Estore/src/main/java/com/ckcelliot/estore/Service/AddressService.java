package com.ckcelliot.estore.Service;

import com.ckcelliot.estore.Entity.Address;
import org.springframework.stereotype.Service;

@Service
public interface AddressService {
    public Address getAddressByUserId(long id);

    public void saveOrUpdate(Address address);
}

package com.ckcelliot.estore.Controller;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ckcelliot.estore.DTO.Email;
import com.ckcelliot.estore.Entity.Address;
import com.ckcelliot.estore.Entity.Cart;
import com.ckcelliot.estore.Entity.Order;
import com.ckcelliot.estore.Entity.OrderItem;
import com.ckcelliot.estore.Entity.Product;
import com.ckcelliot.estore.Entity.User;
import com.ckcelliot.estore.Service.OrderService;
import com.ckcelliot.estore.Service.ProductService;
import com.ckcelliot.estore.Service.Impl.AddressServiceImpl;
import com.ckcelliot.estore.Service.Impl.CartServiceImpl;
import com.ckcelliot.estore.Service.Impl.EmailServiceImpl;
import com.ckcelliot.estore.Service.Impl.UserServiceImpl;
import com.ckcelliot.estore.util.Constants;

@Controller
@RequestMapping("/order")
@AllArgsConstructor
public class OrderController {

	private AddressServiceImpl addressService;

	private UserServiceImpl userService;

	private OrderService orderService;

	private CartServiceImpl cartService;

	private ProductService productService;

	private EmailServiceImpl emailService;

	@GetMapping("/checkout")
	public String orderCheckout(Model model) {
		Address address = null;
		User user = this.userService.getUserDetails();
		if (user != null) {
			address = this.addressService.getAddressByUserId(user.getId());
			model.addAttribute("address", address);
		}
		return "checkout";
	}

	@PostMapping("/process")
	public String processOrder(@RequestParam("street") String street, @RequestParam("city") String city,
			@RequestParam("state") String state, @RequestParam("country") String country,
			@RequestParam("zipCode") String zipCode) {
		User user = this.userService.getUserDetails();
		String redirectUrl = "/index";

		if (user != null) {
			Address address = this.addressService.getAddressByUserId(user.getId());
			if (address != null) {
				address.setStreet(street);
				address.setState(state);
				address.setCity(city);
				address.setCountry(country);
				address.setZipCode(zipCode);
			} else {
				address = new Address(user.getId(), street, city, state, country, zipCode);
			}

			List<Cart> cartItems = this.cartService.getAllCartItemByUserId(user.getId());
			BigDecimal totalPrice = BigDecimal.ZERO;
			for (Cart item : cartItems) {
				Optional<Product> optional = this.productService.getProductById(item.getProdcutId());
				if (optional.isPresent()) {
					Product product = optional.get();
					totalPrice = totalPrice.add(product.getPrice());
				}
			}

			Order order = new Order();
			order.setOrderTrackingNumber(this.orderService.getTrackingId());
			order.setStatus(Constants.ORDER_STATUS_INPROGRESS);
			order.setTotalPrice(totalPrice.add(new BigDecimal(Constants.SHIPPING_CHARGES)));
			order.setTotalQuantity(cartItems.size());
			order.setUser(user);

			Set<OrderItem> orderItems = this.cartService.getOrderItemsByCartList(cartItems);
			for (OrderItem item : orderItems) {
				item.setOrder(order);
			}

			this.addressService.saveOrUpdate(address);

			order.setOrderItems(orderItems);
			this.orderService.save(order);

			this.cartService.deleteByUserId(user.getId());
			redirectUrl = "/payment/process-payment/" + order.getTotalAmount();
		}
		return "redirect:" + redirectUrl;
	}

	@GetMapping("/order-completed") // To Client
	public String orderCompleted() {
		User user = this.userService.getUserDetails();
		if (user != null) {
			Email email = new Email();
			email.setEmailTo(user.getEmail());
			email.setEmailCc("ckcelliot@gmail.com");
			email.setEmailBcc("virtueskingchung@gmail.com");
			email.setSubject(Constants.ORDER_CONFIRMATION_EMAIL);
			email.setEmailBody("Your order has been confirmed");
			this.emailService.sendOrderConfirmationEmail(email);
		}
		return "redirect:/shop";
	}
}

package com.ckcelliot.estore.DTO;

import lombok.Data;

@Data
public class UserLoginDTO {
    private String username;
    private String password;
}

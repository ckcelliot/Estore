package com.ckcelliot.estore.Service.Impl;

import com.ckcelliot.estore.Service.EmailService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.ckcelliot.estore.DTO.Email;

@Service
@AllArgsConstructor
public class EmailServiceImpl implements EmailService {

	private JavaMailSender mailSender;
	
	public void sendOrderConfirmationEmail(Email email) {

		// Input the info as you like
		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom(email.getEmailForm());
		message.setTo(email.getEmailTo());
		message.setSubject(email.getSubject());
		message.setText(email.getEmailBody());
		if (email.getEmailCc() != null && !email.getEmailCc().isEmpty()) {
			message.setCc(email.getEmailCc());
		}
		if (email.getEmailBcc() != null && !email.getEmailBcc().isEmpty()) {
			message.setBcc(email.getEmailBcc());
		}
		mailSender.send(message);
	}
}

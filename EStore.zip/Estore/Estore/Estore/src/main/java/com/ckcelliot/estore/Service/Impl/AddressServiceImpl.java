package com.ckcelliot.estore.Service.Impl;

import java.util.Optional;

import com.ckcelliot.estore.Service.AddressService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ckcelliot.estore.Entity.Address;
import com.ckcelliot.estore.Repository.AddressRepository;

@Service
@AllArgsConstructor
public class AddressServiceImpl implements AddressService {

	private AddressRepository addressRepository;

	public Address getAddressByUserId(long id) {
		Address address = null;
		Optional<Address> optional = this.addressRepository.findByUserId(id);
		if (optional.isPresent()) {
			address = optional.get();
		}
		return address;
	}

	public void saveOrUpdate(Address address) {
		this.addressRepository.save(address);
	}

}

package com.ckcelliot.estore.Controller;

import com.ckcelliot.estore.DTO.UserDTO;
import com.ckcelliot.estore.Entity.PasswordResetToken;
import com.ckcelliot.estore.Entity.Role;
import com.ckcelliot.estore.Entity.User;
import com.ckcelliot.estore.Repository.RoleRepository;
import com.ckcelliot.estore.Repository.TokenRepository;
import com.ckcelliot.estore.Repository.UserRepository;
import com.ckcelliot.estore.Service.Impl.CustomUserDetailsService;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import lombok.AllArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
@AllArgsConstructor
public class LoginController {

	private BCryptPasswordEncoder bCryptPasswordEncoder;

	private UserRepository userRepository;

	private RoleRepository roleRepository;

	private CustomUserDetailsService customUserDetailService;

	private TokenRepository tokenRepository;

	@GetMapping("/login")
	public String login() {
		return "login";
	}

	@GetMapping("/register")
	public String registerGet() {
		return "register";
	}

	@PostMapping("/register")
	public String registerPost(@ModelAttribute("user") User user, HttpServletRequest request) throws ServletException {
		String password = bCryptPasswordEncoder.encode(user.getPassword());
		user.setPassword(password);
		List<Role> roles = new ArrayList<>();
		roles.add(roleRepository.findById(2).get());
		user.setRoles(roles);
		userRepository.save(user);
		request.login(user.getEmail(), password);
		return "redirect:/";
	}

	@GetMapping("/forgotpassword")
	public String forgotPassword() {
		return "forgotpassword";
	}

	@PostMapping("/forgotpassword")
	public String forgotPassordProcess(@ModelAttribute UserDTO userDTO) {
		String output = "";
		// Optional <T>
		Optional<User> user = userRepository.findByEmail(userDTO.getEmail());
		if (user.isPresent()) {
			output = customUserDetailService.sendEmail(user.get());
		}
		if (output.equals("success")) {
			return "redirect:/forgotpassword?success";
		}
		return "redirect:/login?error";
	}

	@GetMapping("/resetpassword/{token}")
	public String resetPasswordForm(@PathVariable String token, Model model) {
		// Optional <T>
		Optional<PasswordResetToken> reset = tokenRepository.findByToken(token);
		if (reset.isPresent() && customUserDetailService.hasExipred(reset.get().getExpiryDateTime())) {
			model.addAttribute("email", reset.get().getUser().getEmail());
			return "resetpassword";
		}
		return "redirect:/forgotpassword?error";
	}

	@PostMapping("/resetpassword")
	public String passwordResetProcess(@ModelAttribute UserDTO userDTO) {
		// Optional <T>
		Optional<User> user = userRepository.findUserByEmail(userDTO.getEmail());
		if(user.isPresent()) {
			user.get().setPassword(bCryptPasswordEncoder.encode(userDTO.getPassword()));
			userRepository.save(user.get());
		}
		return "redirect:/login";
	}
}

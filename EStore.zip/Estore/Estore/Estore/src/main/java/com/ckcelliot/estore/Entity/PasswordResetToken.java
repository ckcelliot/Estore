package com.ckcelliot.estore.Entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "passwordresettoken")
public class PasswordResetToken {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String token;

    private LocalDateTime expiryDateTime;

    // Associated entities are not loaded from the database until you explicitly access them
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user__id", referencedColumnName = "id")
    private User user;

}

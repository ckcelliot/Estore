package com.ckcelliot.estore.Service.Impl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import com.ckcelliot.estore.Service.CartService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ckcelliot.estore.Entity.Cart;
import com.ckcelliot.estore.Entity.OrderItem;
import com.ckcelliot.estore.Entity.Product;
import com.ckcelliot.estore.Repository.CartRepository;

@Service
@AllArgsConstructor
public class CartServiceImpl implements CartService {

	private CartRepository cartRepository;

	private ProductServiceImpl productServiceImpl;

	public void addToCart(Cart cart) {
		this.cartRepository.save(cart);
	}

	public List<Cart> getAllCartItemByUserId(long id) {
		List<Cart> cartItems = null;
		cartItems = this.cartRepository.findCartByUserId(id);
		return cartItems;
	}

	public void deleteById(long id) {
		this.cartRepository.deleteById(id);
	}

	public void deleteByUserId(long id) {
		this.cartRepository.deleteByUserId(id);
	}

	public Set<OrderItem> getOrderItemsByCartList(List<Cart> cartItems) {
		Set<OrderItem> orderItems = new HashSet<>();
		Map<Long, Integer> productCounts = new HashMap<>();
		for (Cart cart : cartItems) {
			long productId = cart.getProdcutId();
			productCounts.put(productId, productCounts.getOrDefault(productId, 0) + 1);
		}
		for (Map.Entry<Long, Integer> entry : productCounts.entrySet()) {
			OrderItem orderItem = new OrderItem();
			Optional<Product> optional = this.productServiceImpl.getProductById(entry.getKey());
			if (optional.isPresent()) {
				Product product = optional.get();
				orderItem.setImageUrl(product.getImageUrl());
				orderItem.setPrice(product.getPrice());
				orderItem.setQuantity(entry.getValue());
				orderItem.setProduct(product);
				orderItems.add(orderItem);
			}
		}
		return orderItems;
	}
}

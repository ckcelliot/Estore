package com.ckcelliot.estore.DTO;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;

@Data
public class Email {
	private String subject;

	private String emailTo;

	@Value("${spring.mail.username}")
	private String emailForm;

	private String emailBody;

	private String emailCc;

	private String emailBcc;

}
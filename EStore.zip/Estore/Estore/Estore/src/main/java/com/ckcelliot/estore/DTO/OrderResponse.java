package com.ckcelliot.estore.DTO;

import lombok.Data;

// From Server to Client
@Data
public class OrderResponse {
    private String orderTackingNumber;
    private String status;
    private String message;
}

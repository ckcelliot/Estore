package com.ckcelliot.estore.Service;

import com.ckcelliot.estore.Entity.Cart;
import com.ckcelliot.estore.Entity.OrderItem;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public interface CartService {
    public void addToCart(Cart cart);

    public List<Cart> getAllCartItemByUserId(long id);

    public void deleteById(long id);

    public void deleteByUserId(long id);

    public Set<OrderItem> getOrderItemsByCartList(List<Cart> cartItems);




}

package com.ckcelliot.estore.Controller;

import com.ckcelliot.estore.DTO.Email;
import com.ckcelliot.estore.Service.Impl.EmailServiceImpl;
import com.ckcelliot.estore.Service.PaypalService;
import com.ckcelliot.estore.util.Constants;
import com.paypal.api.payments.Links;
import com.paypal.api.payments.Payment;
import jakarta.servlet.http.HttpServletRequest;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/payment")
@AllArgsConstructor
public class PaypalController {

    private PaypalService paypalService;

    private EmailServiceImpl emailService;

    public static final String SUCCESS_URL = "/success";
    public static final String CANCEL_URL = "/cancel";
    public static final String BASE_URL = "http://localhost:8080/payment";

    @GetMapping("/process-payment/{amount}")
    public String paypal(@PathVariable("amount") Double amount, HttpServletRequest request){


        try {
            Payment payment = this.paypalService.createPayment(
                    amount, Constants.CURRENCY_USD, "paypal", "SALE",
                    Constants.ONLINE_ORDER_DESCRIPTION, BASE_URL+CANCEL_URL,
                    BASE_URL+SUCCESS_URL);

            for (Links link : payment.getLinks()) {
                if (link.getRel().equals("approval_url")) {
                    return "redirect:" + link.getHref();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "redirect:/";
    }

    @GetMapping(value = SUCCESS_URL)
    public String paymentSuccess(@RequestParam("paymentId") String paymentId, @RequestParam("PayerID") String payerId) {
        System.out.println("paymentId : " + paymentId);
        System.out.println("payerId : " + payerId);

        try {
         Payment payment = this.paypalService.executePayment(paymentId, payerId);
            if (payment.getState().equals("approved")) {
                Email email = new Email();
                email.setEmailTo(payment.getPayer().getPayerInfo().getEmail());
                email.setEmailCc("ckcelliot@gmail.com");
                email.setEmailBcc("virtueskingchung@gmail.com");
                email.setEmailBody("Payment Successfully Received!");
                email.setSubject("PayPal Payment Confirmation");
                this.emailService.sendOrderConfirmationEmail(email);
                return "redirect:/order/order-completed";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "redirect:/order/order-completed";
    }


    @GetMapping(value = CANCEL_URL)
    public String paymentCanel() {
        return "redirect:/";
    }
}

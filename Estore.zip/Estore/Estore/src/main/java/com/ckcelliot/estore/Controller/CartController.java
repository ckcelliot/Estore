package com.ckcelliot.estore.Controller;

import com.ckcelliot.estore.Entity.Cart;
import com.ckcelliot.estore.Entity.Product;
import com.ckcelliot.estore.Entity.User;
import com.ckcelliot.estore.Service.Impl.CartServiceImpl;
import com.ckcelliot.estore.Service.Impl.UserServiceImpl;
import com.ckcelliot.estore.util.Constants;
import com.ckcelliot.estore.Service.ProductService;

import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Controller
@AllArgsConstructor
public class CartController {

	private ProductService productService;

	private CartServiceImpl cartService;

	private UserServiceImpl userService;

	@GetMapping("/add-to-cart/{id}")
	public String addToCartHandler(@PathVariable("id") long id) {
		Cart cart = new Cart();
		cart.setProdcutId(id);
		User user = this.userService.getUserDetails();
		cart.setUserId(user.getId());
		cartService.addToCart(cart);
		return "redirect:/shop";
	}

	@GetMapping("/cart")
	public String cartView(Model model) {

		User user = userService.getUserDetails();
		String redirectUrl = "redirect:/";
		if (user != null) {
			Map<Integer, Product> productItems = new HashMap<>();
			BigDecimal totalPrice = BigDecimal.ZERO;
			List<Cart> cartItems = this.cartService.getAllCartItemByUserId(user.getId());
			model.addAttribute("cartCount", cartItems.size());
			if (!cartItems.isEmpty()) {
				for (Cart item : cartItems) {
					Optional<Product> optional = this.productService.getProductById(item.getProdcutId());
					if (optional.isPresent()) {
						Product product = optional.get();
						productItems.put(item.getId(), product);
						totalPrice = totalPrice.add(product.getPrice());
					}
				}
				redirectUrl = "/cart";
			}
			model.addAttribute("total", totalPrice);
			model.addAttribute("shippingCharge", Constants.SHIPPING_CHARGES);
			model.addAttribute("cartItems", productItems);
		}
		return redirectUrl;
	}

	@GetMapping("/cart/removeItem/{id}")
	public String deleteCartItem(@PathVariable("id") long id) {
		User user = this.userService.getUserDetails();
		if (user != null) {
			this.cartService.deleteById(id);
		}
		return "redirect:/cart";
	}

}

package com.ckcelliot.estore.Service;

import java.math.BigDecimal;
import java.util.Set;

import com.ckcelliot.estore.Entity.Address;
import com.ckcelliot.estore.Entity.Order;
import com.ckcelliot.estore.Entity.OrderItem;
import org.springframework.stereotype.Service;

@Service
public interface OrderService {

	public String getTrackingId();
	
	public void save(Order order);
	
}

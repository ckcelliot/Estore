package com.ckcelliot.estore.Repository;

import com.ckcelliot.estore.Entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

        List<Product> findAllByCategory_Id(int id);

        // JPQL Query
        @Query("SELECT p from Product p where " +
                "p.name LIKE CONCAT('%',:query, '%') or " +
                "p.description LIKE CONCAT('%',:query, '%')")
        List<Product> searchProducts(String query);

        // Native SQL Query
        @Query(value = "SELECT * from products p where " +
                "p.name LIKE CONCAT('%',:query, '%') or " +
                "p.description LIKE CONCAT('%',:query, '%')", nativeQuery = true)
        List<Product> searchProductsSQL(String query);

}

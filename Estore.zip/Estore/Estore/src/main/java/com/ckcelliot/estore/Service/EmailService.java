package com.ckcelliot.estore.Service;

import com.ckcelliot.estore.DTO.Email;
import org.springframework.stereotype.Service;

@Service
public interface EmailService {
    public void sendOrderConfirmationEmail(Email email);
}

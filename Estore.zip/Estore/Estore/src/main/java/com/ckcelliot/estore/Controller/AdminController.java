package com.ckcelliot.estore.Controller;

import com.ckcelliot.estore.DTO.ProductDTO;
import com.ckcelliot.estore.Entity.Product;
import com.ckcelliot.estore.Entity.ProductCategory;
import com.ckcelliot.estore.Service.ProductCategoryService;
import com.ckcelliot.estore.Service.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

@Controller
public class AdminController {

    private ProductCategoryService productCategoryService;

    private ProductService productService;

    public AdminController(ProductCategoryService productCategoryService, ProductService productService) {
        this.productCategoryService = productCategoryService;
        this.productService = productService;
    }

    public static String uploadDir = System.getProperty("user.dir") +
            "/src/main/resources/static/productImages";

    @GetMapping("/admin")
    public String adminHome() {
        return "adminPortal";
    }

    @GetMapping("/admin/categories")
    public String getCat(Model model) {
        model.addAttribute("categories", productCategoryService.getAllCategory());
        return "categories";
    }

    @GetMapping("/admin/categories/add")
    public String getCatAdd(Model model) {
        model.addAttribute("category", new ProductCategory());
        return "addCategories";
    }

    @PostMapping("/admin/categories/add")
    public String postCatAdd(@ModelAttribute("category") ProductCategory productCategory) {
        productCategoryService.addCategory(productCategory);
        return "redirect:/admin/categories";
    }

    @GetMapping("/admin/categories/delete/{id}")
    public String getCatDelete(@PathVariable int id) {
        productCategoryService.deleteCategoryById(id);
        return "redirect:/admin/categories";
    }

    @GetMapping("/admin/categories/update/{id}")
    public String getCatUpdate(@PathVariable int id, Model model) {
        Optional<ProductCategory> productCategory = productCategoryService.getCategoryById(id);
        if (productCategory.isPresent()) {
            model.addAttribute("category", productCategory.get());
            return "addCategories";
        } else
            return "404";
    }

    // Product Section
    @GetMapping("/admin/products")
    public String getProduct(Model model) {
        model.addAttribute("products", productService.getAllProduct());
        return "products";
    }

    @GetMapping("/admin/products/add")
    public String addProduct(Model model) {
        model.addAttribute("productDTO", new ProductDTO());
        model.addAttribute("categories", productCategoryService.getAllCategory());
        return "addProducts";
    }

    @PostMapping("/admin/products/add")
    public String productAddPost(@ModelAttribute("productDTO")ProductDTO productDTO,
                                 @RequestParam("productImage")MultipartFile file,
                                 @RequestParam("imgName")String imgName) throws Exception{
        Product product = new Product();
        product.setId(productDTO.getId());
        product.setSku(productDTO.getSku());
        product.setName(productDTO.getName());
        product.setCategory(productCategoryService.getCategoryById(productDTO.getCategoryId()).get());
        product.setPrice(productDTO.getPrice());
        product.setDescription(productDTO.getDescription());
        String imageUUID;
        if (!file.isEmpty()){
            imageUUID = file.getOriginalFilename();
            Path fileNameAndPath = Paths.get(uploadDir, imageUUID);
            Files.write(fileNameAndPath, file.getBytes());
        } else {
            imageUUID = imgName;
        }
        product.setImageUrl(imageUUID);
        productService.addProduct(product);
        return "redirect:/admin/products";
    }

    @GetMapping("/admin/product/delete/{id}")
    public String deleteProduct(@PathVariable long id) {
        productService.deleteProductById(id);
        return "redirect:/admin/products";
    }

    @GetMapping("/admin/product/update/{id}")
    public String updateProductGet(@PathVariable long id, Model model){
        Product product = productService.getProductById(id).get();
        ProductDTO productDTO = new ProductDTO();
        productDTO.setId(product.getId());
        productDTO.setSku(product.getSku());
        product.setName(product.getName());
        productDTO.setCategoryId((int) product.getCategory().getId());
        productDTO.setDescription(product.getDescription());
        productDTO.setPrice(product.getPrice());
        productDTO.setImageUrl(product.getImageUrl());
        model.addAttribute("categories", productCategoryService.getAllCategory());
        model.addAttribute("productDTO", productDTO);
        return "addProducts";
    }
}

package com.ckcelliot.estore.Service.Impl;

import java.math.BigDecimal;
import java.util.Set;
import java.util.UUID;

import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ckcelliot.estore.Entity.Address;
import com.ckcelliot.estore.Entity.Order;
import com.ckcelliot.estore.Entity.OrderItem;
import com.ckcelliot.estore.Repository.OrderRepository;
import com.ckcelliot.estore.Service.OrderService;
import com.ckcelliot.estore.util.Constants;

@Service
@AllArgsConstructor
public class OrderServiceImpl implements OrderService {

	private OrderRepository orderRepository;

	@Override
	public String getTrackingId() {
		String trackingId = "";
		trackingId = UUID.randomUUID().toString().replace("-", "");
		return trackingId;
	}

	@Override
	public void save(Order order) {
		this.orderRepository.save(order);
	}
}

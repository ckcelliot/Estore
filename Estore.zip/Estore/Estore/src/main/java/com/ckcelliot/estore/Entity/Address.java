package com.ckcelliot.estore.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "addresses")
@Data
public class Address {

	@Id
	@Column(name = "user_id")
	private long userId;

	private String street;
	private String city;
	private String state;
	private String country;
	private String zipCode;

	public Address(long userId, String street, String city, String state, String country, String zipCode) {
		this.userId = userId;
		this.street = street;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zipCode = zipCode;
	}

	public Address() {
	}
	
	@Override
	public String toString() {
		return "Address [userId=" + userId +
				", street=" + street +
				", city=" + city +
				", state=" + state +
				", country="
				+ country +
				", zipCode=" + zipCode + "]";
	}
}

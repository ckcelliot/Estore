package com.ckcelliot.estore.Service;

import com.ckcelliot.estore.Entity.Product;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface ProductService {
    List<Product> searchProducts(String query);

    Product createProduct(Product product);

    public List<Product> getAllProduct();

    public void addProduct(Product product);

    public void deleteProductById(long id);

    Optional<Product> getProductById(long id);

    public List<Product> getAllProductsByCategoryId(int id);
}
